$(document).ready(function(){
  //修改文本：鼠标悬停，添加修改按钮，显示灰底
  $(".ymTextClass").parent().hover(function(){
    //划到当前元素的div里面背景变灰
    $(this).css("background","lightgrey");
    //右上角显示按钮功能
    $(this).append("<a id='moBtn' class='btn btn-primary btn-sm' style='position:absolute;top:0;right:0;visibility: visible ;'>修改</a>");
    //点击按钮弹窗提示
    $("#moBtn").click(function(){
      var ymid = $(this).prev().attr("id");
      $("#ymFixid").val(ymid);
      var waitformodify = $("#"+ymid).text();
      $("#modifyTextArea").val(waitformodify);
      $("#modifyText").modal("toggle");
    })
  },function(){
    $(this).css("background","none");
    $("#moBtn").remove();
  })
  //获取新文本修改旧文本
  $("#modifyTextAreaBtn").click(function(){
    var ymFixid = $("#ymFixid").val();
    console.log(ymFixid);
    var modified = $("#modifyTextArea").val();
    $("#"+ymFixid).text(modified);
  })

  //修改链接的内容
  $(".ymAttrClass").parent().hover(function(){
    //划到当前元素的div里面背景变灰
    $(this).css("background","lightgrey");
    //右上角显示按钮功能
    $(this).append("<a id='moBtn' class='btn btn-primary btn-sm' style='position:absolute;top:0;right:0;visibility: visible ;'>修改</a>");
    //点击按钮弹窗提示
    $("#moBtn").click(function(){
      //获取button前面的元素的id，也就是取值和赋值的id
      var ymid = $(this).prev().attr("id");
      //将获取到的前面元素的值赋给隐藏元素span
      $("#ymFixid").val(ymid);
      //将取出的链接赋给模态窗口的文本编辑器
      var waitformodify = $("#"+ymid).attr("href");
      $("#modifyAttrArea").val(waitformodify);
      //调用bootstrap的模态窗口
      $("#modifyAttr").modal("toggle");
    })
  },function(){
    $(this).css("background","unset");
    $("#moBtn").remove();
  })
  //获取新链接修改旧链接
  $("#modifyAttrAreaBtn").click(function(){
    //获取隐藏span的id值
    var ymFixid = $("#ymFixid").val();
    console.log(ymFixid);
    //获取模态窗口的文本框的值
    var modified = $("#modifyAttrArea").val();
    console.log(modified);
    //将修改后的文本赋值给href属性
    $("#"+ymFixid).attr("href",modified);
  })

  //修改图片的内容
  $(".ymImgClass").parent().hover(function(){
    //划到当前元素的div里面背景变灰
    $(this).css("background","lightgrey");
    //右上角显示按钮功能
    $(this).append("<a id='moBtn' class='btn btn-primary btn-sm' style='position:absolute;top:0;right:0;visibility: visible ;'>修改</a>");
    //点击按钮弹窗提示
    $("#moBtn").click(function(){
      //获取button前面的元素的id，也就是取值和赋值的id
      var ymid = $(this).prev().attr("id");
      //将获取到的前面元素的值赋给隐藏元素span
      $("#ymFixid").val(ymid);
      //将取出的链接赋给模态窗口的文本编辑器
      var waitformodify = $("#"+ymid).attr("src");
      $("#modifyImgArea").val(waitformodify);
      //调用bootstrap的模态窗口
      $("#modifyImg").modal("toggle");
    })
  },function(){
    $(this).css("background","unset");
    $("#moBtn").remove();
  })
  //获取修改后的值赋给新的
  $("#modifyImgAreaBtn").click(function(){
    //获取隐藏span的id值
    var ymFixid = $("#ymFixid").val();
    console.log(ymFixid);
    //获取模态窗口的文本框的值
    var modified = $("#modifyImgArea").val();
    console.log(modified);
    //将修改后的文本赋值给href属性
    $("#"+ymFixid).attr("src",modified);
  })
});